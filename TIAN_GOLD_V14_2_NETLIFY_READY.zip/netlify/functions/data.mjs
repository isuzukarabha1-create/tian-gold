import { getStore } from '@netlify/blobs';
import { createHash } from 'node:crypto';

const store = getStore({ name: 'tian-gold-data', consistency: 'strong' });
const KEY = 'app-state';
const DEFAULT_PIN = '888999';
const MASTER_KADAR = [
  {n:'6K',kadar:'300',p:0.27},{n:'8K',kadar:'375',p:0.34},{n:'9–10K',kadar:'420',p:0.37},{n:'16K',kadar:'700',p:0.67},
  {n:'17–18K',kadar:'750',p:0.71},{n:'21K',kadar:'',p:0.84},{n:'22K',kadar:'',p:0.89},{n:'23–24K',kadar:'',p:0.91}
];
const hashPin = pin => createHash('sha256').update(String(pin)).digest('hex');
const baseState = () => ({
  initialized:false,
  pinHash:hashPin(DEFAULT_PIN),
  hargaDasar:2335000,
  history:[{date:'25 Agu 2026',price:2335000}],
  kadarList:MASTER_KADAR,
  transaksi:[]
});
async function readState(){return await store.get(KEY,{type:'json'}) || baseState();}
export default async req=>{
  try{
    if(req.method==='GET'){
      const s=await readState();const {pinHash,...safe}=s;return Response.json({...safe,pinConfigured:true});
    }
    if(req.method!=='POST')return new Response('Method Not Allowed',{status:405});
    const body=await req.json();const s=await readState();
    if(body.action==='login')return Response.json({ok:hashPin(body.pin)===s.pinHash});
    if(body.action==='changePin'){
      if(hashPin(body.oldPin)!==s.pinHash)return Response.json({ok:false,error:'PIN lama salah'},{status:401});
      if(!/^\d{4,12}$/.test(String(body.newPin)))return Response.json({ok:false,error:'PIN baru harus 4-12 digit angka'},{status:400});
      s.pinHash=hashPin(body.newPin);s.initialized=true;await store.setJSON(KEY,s);return Response.json({ok:true});
    }
    if(body.action==='save'){
      const incoming=body.state||{};
      s.hargaDasar=Number(incoming.hargaDasar||s.hargaDasar);
      s.history=Array.isArray(incoming.history)?incoming.history:s.history;
      s.kadarList=Array.isArray(incoming.kadarList)&&incoming.kadarList.length?incoming.kadarList:MASTER_KADAR;
      s.transaksi=Array.isArray(incoming.transaksi)?incoming.transaksi:s.transaksi;
      s.initialized=true;await store.setJSON(KEY,s);return Response.json({ok:true});
    }
    if(body.action==='resetAll'){const fresh=baseState();fresh.initialized=true;await store.setJSON(KEY,fresh);return Response.json({ok:true});}
    return Response.json({ok:false,error:'Aksi tidak dikenal'},{status:400});
  }catch(err){console.error(err);return Response.json({ok:false,error:'Server error'},{status:500});}
};
